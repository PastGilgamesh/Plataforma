using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float velocidade;
    bool ViradoDireita = true;
    private Rigidbody2D rb;
    public float ForcaPulo;
    public int ContaPulos;
    public Animator anim;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        float PosX = Input.GetAxis("Horizontal") * Time.deltaTime * velocidade;
        transform.Translate(new Vector3(PosX, 0, 0));

        if (PosX != 0)
        {
            anim.SetBool("Run", true);
        }

        else
        {
            anim.SetBool("Run", false);

        }

        if (PosX < 0 && ViradoDireita)
        {
            Flip();
            ViradoDireita = false;
        }

        if (PosX > 0 && !ViradoDireita)
        {
            Flip();
            ViradoDireita = true;
        }

        if (Input.GetKeyDown(KeyCode.Space) && ContaPulos <= 1)
        {
            rb.AddForce(new Vector2(0, 1f) * ForcaPulo);
            ContaPulos++;
            anim.SetBool("Jump", true);
        }

        void Flip()
        {
            Vector3 GuardaEscala;
            GuardaEscala = transform.localScale;
            GuardaEscala.x *= -1; // GuardaEscala.x = GuardaEscala.x *(-1);
            transform.localScale = GuardaEscala;

        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Plataforma"))
        {
            ContaPulos = 0;
            anim.SetBool("Jump", false);
        }

    }




}